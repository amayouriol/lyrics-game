/* @ds-bundle: {"format":4,"namespace":"ColorPaletteDesignSystem_2280bf","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"LyricBlank","sourcePath":"components/game/LyricBlank.jsx"},{"name":"StatBlock","sourcePath":"components/game/StatBlock.jsx"},{"name":"PlayerBar","sourcePath":"components/music/PlayerBar.jsx"},{"name":"SongCard","sourcePath":"components/music/SongCard.jsx"}],"sourceHashes":{"components/core/Button.jsx":"6a46b3a5e9b2","components/core/Chip.jsx":"27a006b2faf3","components/game/LyricBlank.jsx":"0635d140df31","components/game/StatBlock.jsx":"1994fe7d800e","components/music/PlayerBar.jsx":"c3ed89eed63a","components/music/SongCard.jsx":"893afcb320e5","ui_kits/lyric-roulette/App.jsx":"b93ecab25f07","ui_kits/lyric-roulette/Browse.jsx":"2432575908d1","ui_kits/lyric-roulette/Home.jsx":"1a79735f7a2e","ui_kits/lyric-roulette/Nav.jsx":"27cd5f5c03d9","ui_kits/lyric-roulette/Play.jsx":"b32684d229bd","ui_kits/lyric-roulette/Profile.jsx":"d24f7ca86510","ui_kits/lyric-roulette/Results.jsx":"8de4eb63b1de","ui_kits/lyric-roulette/data.js":"e23de2a537f4"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ColorPaletteDesignSystem_2280bf = window.ColorPaletteDesignSystem_2280bf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
const {
  useState
} = React;
const V = {
  primary: {
    bg: 'var(--primary-400)',
    hv: 'var(--primary-500)',
    pr: 'var(--primary-600)',
    fg: 'var(--white)',
    bd: 'transparent'
  },
  secondary: {
    bg: 'var(--white)',
    hv: 'var(--grey-100)',
    pr: 'var(--grey-200)',
    fg: 'var(--black)',
    bd: 'var(--grey-200)'
  },
  ghost: {
    bg: 'transparent',
    hv: 'var(--grey-100)',
    pr: 'var(--grey-200)',
    fg: 'var(--black)',
    bd: 'transparent'
  },
  choice: {
    bg: 'var(--tertiary-100)',
    hv: 'var(--tertiary-200)',
    pr: 'var(--tertiary-300)',
    fg: 'var(--tertiary-700)',
    bd: 'transparent'
  }
};
const S = {
  sm: [32, 12, 14],
  md: [40, 16, 14],
  lg: [56, 24, 16]
};
function Button({
  variant = 'primary',
  size = 'md',
  state = 'default',
  full = false,
  disabled = false,
  onClick,
  children,
  style
}) {
  const [hover, setHover] = useState(false);
  const [press, setPress] = useState(false);
  const v = V[variant] || V.primary;
  const [h, px, fs] = S[size] || S.md;
  const isChoice = variant === 'choice';
  let bg = press ? v.pr : hover ? v.hv : v.bg,
    fg = v.fg,
    bd = v.bd,
    deco = 'none';
  if (state === 'correct') {
    bg = 'var(--secondary-100)';
    fg = 'var(--secondary-700)';
    bd = 'transparent';
  }
  if (state === 'wrong') {
    bg = 'var(--grey-100)';
    fg = 'var(--grey-400)';
    bd = 'transparent';
    deco = 'line-through';
  }
  if (disabled) {
    bg = 'var(--grey-100)';
    fg = 'var(--grey-400)';
    bd = 'transparent';
  }
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      height: h,
      padding: `0 ${px}px`,
      width: full ? '100%' : undefined,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      border: `1px solid ${bd}`,
      borderRadius: 'var(--radius-swatch)',
      background: bg,
      color: fg,
      font: `${isChoice ? 400 : 600} ${isChoice ? fs + 4 : fs}px/1 ${isChoice ? 'var(--font-display)' : 'var(--font-sans)'}`,
      textDecoration: deco,
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background 120ms ease, color 120ms ease',
      whiteSpace: 'nowrap',
      boxSizing: 'border-box',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
const {
  useState
} = React;
function Chip({
  tone = 'grey',
  selected = false,
  size = 'md',
  onClick,
  children
}) {
  const [hover, setHover] = useState(false);
  const bg = selected ? `var(--${tone}-600)` : hover && onClick ? `var(--${tone}-200)` : `var(--${tone}-100)`;
  const fg = selected ? 'var(--white)' : `var(--${tone}-600)`;
  const Tag = onClick ? 'button' : 'span';
  return /*#__PURE__*/React.createElement(Tag, {
    type: onClick ? 'button' : undefined,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      height: size === 'sm' ? 24 : 32,
      padding: size === 'sm' ? '0 8px' : '0 12px',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      border: 0,
      borderRadius: 'var(--radius-swatch)',
      background: bg,
      color: fg,
      font: `600 ${size === 'sm' ? 12 : 14}px/1 var(--font-sans)`,
      cursor: onClick ? 'pointer' : 'default',
      whiteSpace: 'nowrap',
      transition: 'background 120ms ease',
      boxSizing: 'border-box'
    }
  }, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/game/LyricBlank.jsx
try { (() => {
function LyricBlank({
  answer = '',
  value = '',
  state = 'empty',
  mode = 'choice',
  onChange,
  onSubmit
}) {
  const w = Math.max(answer.length, 3) + 1;
  const base = {
    display: 'inline-block',
    minWidth: `${w}ch`,
    padding: '0 0.15em',
    borderRadius: 6,
    textAlign: 'center',
    boxSizing: 'border-box'
  };
  if (state === 'active' && mode === 'type') {
    return /*#__PURE__*/React.createElement("input", {
      autoFocus: true,
      value: value,
      "aria-label": "Missing word",
      spellCheck: false,
      autoComplete: "off",
      onChange: e => onChange && onChange(e.target.value),
      onKeyDown: e => {
        if (e.key === 'Enter' && onSubmit) onSubmit(value);
      },
      style: {
        ...base,
        width: `${w}ch`,
        font: 'inherit',
        color: 'var(--primary-600)',
        background: 'var(--quaternary-100)',
        border: 0,
        borderBottom: '3px solid var(--primary-400)',
        borderRadius: '6px 6px 0 0',
        outline: 'none',
        verticalAlign: 'baseline'
      }
    });
  }
  if (state === 'active') return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      background: 'var(--quaternary-100)',
      borderBottom: '3px solid var(--primary-400)',
      borderRadius: '6px 6px 0 0'
    }
  }, '\u00a0');
  if (state === 'correct') return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      background: 'var(--secondary-100)',
      color: 'var(--secondary-700)'
    }
  }, answer);
  if (state === 'wrong') {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        ...base,
        background: 'var(--tertiary-100)',
        color: 'var(--tertiary-600)'
      }
    }, value && /*#__PURE__*/React.createElement("s", {
      style: {
        color: 'var(--grey-400)',
        marginRight: '0.35em'
      }
    }, value), answer);
  }
  if (state === 'revealed') return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      background: 'var(--grey-100)',
      color: 'var(--grey-600)'
    }
  }, answer);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      borderBottom: '3px solid var(--grey-200)'
    }
  }, '\u00a0');
}
Object.assign(__ds_scope, { LyricBlank });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/LyricBlank.jsx", error: String((e && e.message) || e) }); }

// components/game/StatBlock.jsx
try { (() => {
function StatBlock({
  label,
  value,
  tone = 'grey',
  hint
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: `var(--${tone}-100)`,
      borderRadius: 'var(--radius-swatch)',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 14px/1.2 var(--font-sans)',
      color: `var(--${tone}-600)`
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 48px/1 var(--font-display)',
      color: `var(--${tone}-700)`
    }
  }, value), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1.4 var(--font-sans)',
      color: `var(--${tone}-600)`
    }
  }, hint));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/music/PlayerBar.jsx
try { (() => {
const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
function PlayerBar({
  title,
  artist,
  tone = 'primary',
  playing = false,
  position = 0,
  duration = 0,
  onToggle
}) {
  const pct = duration ? Math.min(100, position / duration * 100) : 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      height: 72,
      padding: '0 24px',
      background: 'var(--white)',
      borderTop: '1px solid var(--grey-100)',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      minWidth: 0,
      width: 240,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-swatch)',
      background: `var(--${tone}-300)`,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '600 14px/1.4 var(--font-sans)',
      color: 'var(--black)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '400 14px/1.4 var(--font-sans)',
      color: 'var(--grey-500)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, artist))), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onToggle,
    "aria-label": playing ? 'Pause' : 'Play',
    style: {
      width: 40,
      height: 40,
      flexShrink: 0,
      borderRadius: '50%',
      border: 0,
      background: 'var(--primary-400)',
      color: 'var(--white)',
      cursor: 'pointer',
      font: '400 14px/1 var(--font-mono)'
    }
  }, playing ? '❚❚' : '▶'), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 13px var(--font-mono)',
      color: 'var(--grey-500)'
    }
  }, fmt(position)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 4,
      background: 'var(--grey-100)',
      borderRadius: 2,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: '100%',
      background: `var(--${tone}-400)`,
      transition: 'width 1s linear'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 13px var(--font-mono)',
      color: 'var(--grey-500)'
    }
  }, fmt(duration)));
}
Object.assign(__ds_scope, { PlayerBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/music/PlayerBar.jsx", error: String((e && e.message) || e) }); }

// components/music/SongCard.jsx
try { (() => {
const {
  useState
} = React;
function SongCard({
  title,
  artist,
  tone = 'primary',
  snippet,
  meta,
  onClick
}) {
  const [hover, setHover] = useState(false);
  return /*#__PURE__*/React.createElement("div", {
    role: "button",
    tabIndex: 0,
    onClick: onClick,
    onKeyDown: e => {
      if (e.key === 'Enter' && onClick) onClick();
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      cursor: onClick ? 'pointer' : 'default',
      minWidth: 0,
      outline: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '1 / 1',
      borderRadius: 'var(--radius-swatch)',
      background: `var(--${tone}-${hover ? 300 : 200})`,
      padding: 16,
      display: 'flex',
      alignItems: 'flex-end',
      boxSizing: 'border-box',
      transition: 'background 160ms ease'
    }
  }, snippet && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 20px/1.25 var(--font-display)',
      color: `var(--${tone}-700)`,
      textWrap: 'pretty'
    }
  }, snippet)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 14px/1.4 var(--font-sans)',
      color: 'var(--black)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1.4 var(--font-sans)',
      color: 'var(--grey-500)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, artist), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 13px/1.4 var(--font-mono)',
      color: 'var(--grey-500)'
    }
  }, meta)));
}
Object.assign(__ds_scope, { SongCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/music/SongCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/App.jsx
try { (() => {
(function () {
  const {
    useState,
    useEffect
  } = React;
  function App() {
    const LR = window.LR;
    const saved = JSON.parse(localStorage.getItem('lr-route') || 'null') || {
      route: 'home',
      params: {}
    };
    const [route, setRoute] = useState(saved.route === 'results' ? 'home' : saved.route);
    const [params, setParams] = useState(saved.params || {});
    const [result, setResult] = useState(null);
    const [history, setHistory] = useState(LR.history);
    const go = (r, p = {}) => {
      setRoute(r);
      setParams(p);
      window.scrollTo(0, 0);
    };
    useEffect(() => {
      localStorage.setItem('lr-route', JSON.stringify({
        route,
        params
      }));
    }, [route, params]);
    const spin = () => {
      const s = LR.songs[Math.floor(Math.random() * LR.songs.length)];
      go('play', {
        id: s.id,
        n: Date.now()
      });
    };
    const song = LR.songs.find(s => s.id === params.id) || LR.songs[0];
    const onFinish = r => {
      const pct = Math.round(r.answers.filter(a => a.ok).length / r.blanks.length * 100);
      setResult(r);
      setHistory(h => [{
        songId: r.song.id,
        date: 'Today',
        mode: r.difficulty === 'hard' ? 'Hard' : 'Easy',
        timed: r.timed,
        pct,
        score: window.scoreOf(r)
      }, ...h]);
      setRoute('results');
      window.scrollTo(0, 0);
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100vh',
        background: 'var(--white)'
      }
    }, /*#__PURE__*/React.createElement(Nav, {
      route: route,
      go: go,
      streak: 4
    }), route === 'home' && /*#__PURE__*/React.createElement(Home, {
      go: go,
      spin: spin
    }), route === 'browse' && /*#__PURE__*/React.createElement(Browse, {
      go: go,
      params: params
    }), route === 'play' && /*#__PURE__*/React.createElement(Play, {
      key: song.id + (params.n || '') + (params.d || ''),
      song: song,
      initialDifficulty: params.d,
      onFinish: onFinish
    }), route === 'results' && result && /*#__PURE__*/React.createElement(Results, {
      result: result,
      spin: spin,
      replay: d => go('play', {
        id: result.song.id,
        d,
        n: Date.now()
      })
    }), route === 'profile' && /*#__PURE__*/React.createElement(Profile, {
      history: history,
      go: go
    }));
  }
  ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Browse.jsx
try { (() => {
(function () {
  const {
    Chip,
    SongCard
  } = window.ColorPaletteDesignSystem_2280bf;
  const {
    useState,
    useEffect
  } = React;
  const h2 = {
    margin: 0,
    font: '500 32px/1.19 var(--font-sans)',
    letterSpacing: '-0.6px'
  };
  function Browse({
    go,
    params
  }) {
    const {
      songs,
      artists,
      genres,
      blankCount,
      fmt
    } = window.LR;
    const [q, setQ] = useState(params.q || '');
    const [genre, setGenre] = useState(params.genre || null);
    const [artist, setArtist] = useState(null);
    useEffect(() => {
      setQ(params.q || '');
      setGenre(params.genre || null);
    }, [params]);
    const ql = q.trim().toLowerCase();
    const hay = s => (s.title + ' ' + s.artist + ' ' + s.lines.flat().map(p => typeof p === 'string' ? p : p.a).join(' ')).toLowerCase();
    const list = songs.filter(s => (!genre || s.genre === genre) && (!artist || s.artist === artist) && (!ql || hay(s).includes(ql)));
    return /*#__PURE__*/React.createElement("main", {
      style: {
        padding: '72px var(--lr-pad)',
        display: 'flex',
        flexDirection: 'column',
        gap: 72,
        maxWidth: 1260,
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        font: '500 48px/1.19 var(--font-sans)',
        letterSpacing: '-1px'
      }
    }, ql ? `Results for “${q.trim()}”` : 'Browse'), /*#__PURE__*/React.createElement("input", {
      value: q,
      onChange: e => setQ(e.target.value),
      placeholder: "A title, an artist, or a lyric you half remember",
      style: {
        height: 56,
        padding: '0 20px',
        border: '1px solid var(--grey-200)',
        borderRadius: 8,
        font: '400 20px var(--font-sans)',
        letterSpacing: '-0.4px',
        color: 'var(--black)',
        outline: 'none',
        maxWidth: 720
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      selected: !genre,
      onClick: () => setGenre(null)
    }, "All"), genres.map(g => /*#__PURE__*/React.createElement(Chip, {
      key: g,
      tone: "primary",
      selected: genre === g,
      onClick: () => setGenre(genre === g ? null : g)
    }, g)))), !ql && /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: h2
    }, "Artists"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 32,
        flexWrap: 'wrap'
      }
    }, artists.map(a => {
      const on = artist === a.name;
      return /*#__PURE__*/React.createElement("button", {
        key: a.name,
        onClick: () => setArtist(on ? null : a.name),
        style: {
          all: 'unset',
          cursor: 'pointer',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 12,
          width: 96
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 72,
          height: 72,
          borderRadius: '50%',
          background: `var(--${a.tone}-200)`,
          display: 'grid',
          placeItems: 'center',
          font: '500 24px var(--font-display)',
          color: `var(--${a.tone}-700)`,
          boxShadow: on ? `0 0 0 3px var(--white), 0 0 0 6px var(--${a.tone}-400)` : 'none'
        }
      }, a.name.split(' ').filter(w => /^[A-Z]/.test(w)).slice(-2).map(w => w[0]).join('')), /*#__PURE__*/React.createElement("span", {
        style: {
          font: `${on ? 600 : 400} 14px/1.3 var(--font-sans)`,
          textAlign: 'center'
        }
      }, a.name));
    }))), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: h2
    }, list.length, " ", list.length === 1 ? 'song' : 'songs'), list.length ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
        gap: 24
      }
    }, list.map(s => /*#__PURE__*/React.createElement(SongCard, {
      key: s.id,
      title: s.title,
      artist: s.artist,
      tone: s.tone,
      snippet: s.snippet,
      meta: `${blankCount(s)} blanks · ${fmt(s.dur)}`,
      onClick: () => go('play', {
        id: s.id
      })
    }))) : /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: '400 20px/31px var(--font-sans)',
        color: 'var(--grey-500)'
      }
    }, "Nothing. Either it's too obscure or you misspelled it. We won't say which.")));
  }
  window.Browse = Browse;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Browse.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Home.jsx
try { (() => {
(function () {
  const {
    Button,
    Chip,
    SongCard,
    LyricBlank
  } = window.ColorPaletteDesignSystem_2280bf;
  const grid = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: 24
  };
  const h2 = {
    margin: 0,
    font: '500 32px/1.19 var(--font-sans)',
    letterSpacing: '-0.6px'
  };
  function Home({
    go,
    spin
  }) {
    const {
      songs,
      genres,
      blankCount,
      fmt
    } = window.LR;
    return /*#__PURE__*/React.createElement("main", {
      style: {
        padding: '72px var(--lr-pad)',
        display: 'flex',
        flexDirection: 'column',
        gap: 72,
        maxWidth: 1260,
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))',
        gap: 48,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        font: '500 clamp(48px, 6vw, 79px)/1.19 var(--font-sans)',
        letterSpacing: '-1.501px',
        textWrap: 'balance'
      }
    }, "Finish the line. Prove you were listening."), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        maxWidth: 585,
        font: '400 20px/31px var(--font-sans)',
        letterSpacing: '-0.4px',
        color: 'var(--text-body)'
      }
    }, "Pick a song, fill the blanks while it plays, and find out if you know the words \u2014 or just hum with confidence."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      onClick: spin
    }, "Spin the roulette"), /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "secondary",
      onClick: () => go('browse')
    }, "Browse songs"))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--tertiary-100)',
        borderRadius: 16,
        padding: 48,
        display: 'flex',
        flexDirection: 'column',
        gap: 24,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      tone: "tertiary",
      size: "sm"
    }, "Today's line"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        font: '400 40px/1.35 var(--font-display)',
        color: 'var(--grey-600)'
      }
    }, "every light across the ", /*#__PURE__*/React.createElement(LyricBlank, {
      answer: "city"
    }), /*#__PURE__*/React.createElement("br", null), "was a promise we could ", /*#__PURE__*/React.createElement(LyricBlank, {
      answer: "keep",
      state: "correct"
    })), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => go('play', {
        id: 's1'
      }),
      style: {
        color: 'var(--tertiary-600)',
        padding: 0
      }
    }, "Neon Tide \u2014 The Paper Lanterns \u2192"))), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: h2
    }, "Hot right now"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => go('browse')
    }, "See all")), /*#__PURE__*/React.createElement("div", {
      style: grid
    }, songs.slice(0, 4).map(s => /*#__PURE__*/React.createElement(SongCard, {
      key: s.id,
      title: s.title,
      artist: s.artist,
      tone: s.tone,
      snippet: s.snippet,
      meta: `${blankCount(s)} blanks · ${fmt(s.dur)}`,
      onClick: () => go('play', {
        id: s.id
      })
    })))), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: h2
    }, "Pick your poison"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        flexWrap: 'wrap'
      }
    }, genres.map((g, i) => /*#__PURE__*/React.createElement(Chip, {
      key: g,
      tone: ['primary', 'secondary', 'tertiary', 'quaternary', 'grey'][i % 5],
      onClick: () => go('browse', {
        genre: g
      })
    }, g)))));
  }
  window.Home = Home;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Nav.jsx
try { (() => {
(function () {
  const {
    Button,
    Chip
  } = window.ColorPaletteDesignSystem_2280bf;
  function Nav({
    route,
    go,
    streak
  }) {
    const [q, setQ] = React.useState('');
    const links = [['home', 'Home'], ['browse', 'Browse'], ['profile', 'Profile']];
    return /*#__PURE__*/React.createElement("header", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 24,
        height: 72,
        padding: '0 var(--lr-pad)',
        borderBottom: '1px solid var(--grey-100)',
        background: 'var(--white)',
        position: 'sticky',
        top: 0,
        zIndex: 5
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => go('home'),
      style: {
        all: 'unset',
        cursor: 'pointer',
        font: '500 22px var(--font-display)',
        letterSpacing: '-0.5px',
        whiteSpace: 'nowrap'
      }
    }, "Lyric Roulette"), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: 'flex',
        gap: 4
      }
    }, links.map(([k, l]) => /*#__PURE__*/React.createElement(Button, {
      key: k,
      variant: "ghost",
      size: "sm",
      onClick: () => go(k),
      style: route === k ? {
        background: 'var(--grey-100)'
      } : null
    }, l))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement("input", {
      value: q,
      onChange: e => setQ(e.target.value),
      placeholder: "Search songs, artists, that one line\u2026",
      onKeyDown: e => {
        if (e.key === 'Enter') {
          go('browse', {
            q
          });
          setQ('');
        }
      },
      style: {
        width: 280,
        minWidth: 0,
        height: 40,
        padding: '0 12px',
        border: 0,
        borderRadius: 8,
        background: 'var(--grey-100)',
        font: '400 14px var(--font-sans)',
        color: 'var(--black)',
        outline: 'none'
      }
    }), /*#__PURE__*/React.createElement(Chip, {
      tone: "quaternary"
    }, streak, "-day streak"));
  }
  window.Nav = Nav;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Play.jsx
try { (() => {
(function () {
  const {
    Button,
    Chip,
    LyricBlank,
    PlayerBar
  } = window.ColorPaletteDesignSystem_2280bf;
  const {
    useState,
    useEffect,
    useMemo
  } = React;
  const TIME = 60;
  function choicesFor(a, i) {
    const pool = window.LR.allAnswers.filter(x => x.toLowerCase() !== a.toLowerCase());
    const pick = pool.map((x, k) => [((k + 3) * 9301 + (i + 1) * 49297 + a.length * 233) % 233280, x]).sort((p, q) => p[0] - q[0]).slice(0, 3).map(p => p[1]);
    pick.splice((i * 7 + a.length) % 4, 0, a);
    return pick;
  }
  function Play({
    song,
    onFinish,
    initialDifficulty
  }) {
    const [difficulty, setDifficulty] = useState(initialDifficulty || 'easy');
    const [timed, setTimed] = useState(false);
    const [started, setStarted] = useState(false);
    const [idx, setIdx] = useState(0);
    const [answers, setAnswers] = useState([]);
    const [val, setVal] = useState('');
    const [left, setLeft] = useState(TIME);
    const [pos, setPos] = useState(0);
    const [playing, setPlaying] = useState(false);
    const [flash, setFlash] = useState(null);
    const blanks = useMemo(() => {
      const o = [];
      song.lines.forEach((l, li) => l.forEach(p => {
        if (typeof p !== 'string') o.push({
          li,
          a: p.a
        });
      }));
      return o;
    }, [song]);
    const reset = () => {
      setStarted(false);
      setIdx(0);
      setAnswers([]);
      setVal('');
      setLeft(TIME);
      setPos(0);
      setPlaying(false);
      setFlash(null);
    };
    const finish = ans => onFinish({
      song,
      answers: ans,
      blanks,
      difficulty,
      timed,
      elapsed: timed ? TIME - left : pos
    });
    useEffect(() => {
      if (!started || !playing) return;
      const t = setInterval(() => {
        setPos(p => Math.min(p + 1, song.dur));
        if (timed) setLeft(l => l - 1);
      }, 1000);
      return () => clearInterval(t);
    }, [started, playing, timed]);
    useEffect(() => {
      if (timed && started && left <= 0) finish(answers);
    }, [left]);
    const advance = next => {
      if (next.length >= blanks.length) finish(next);else setIdx(next.length);
    };
    const submit = v => {
      if (!started || flash) return;
      const ok = v.trim().toLowerCase() === blanks[idx].a.toLowerCase();
      const next = [...answers, {
        v: v.trim(),
        ok
      }];
      setAnswers(next);
      setVal('');
      if (difficulty === 'easy') {
        setFlash({
          v,
          ok
        });
        setTimeout(() => {
          setFlash(null);
          advance(next);
        }, 500);
      } else advance(next);
    };
    const activeLine = started && blanks[idx] ? blanks[idx].li : -1;
    const correct = answers.filter(a => a.ok).length;
    let bi = -1;
    const setMode = m => {
      setDifficulty(m);
      reset();
    };
    const setPace = t => {
      setTimed(t);
      reset();
    };
    return /*#__PURE__*/React.createElement("main", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        minHeight: 'calc(100vh - 72px)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        width: '100%',
        maxWidth: 1260,
        margin: '0 auto',
        padding: '48px var(--lr-pad) 72px',
        display: 'flex',
        flexDirection: 'column',
        gap: 48,
        boxSizing: 'border-box'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        gap: 24,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      tone: song.tone,
      size: "sm"
    }, song.genre), /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        font: '500 48px/1.19 var(--font-sans)',
        letterSpacing: '-1px'
      }
    }, song.title), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '400 20px/31px var(--font-sans)',
        letterSpacing: '-0.4px',
        color: 'var(--grey-500)'
      }
    }, song.artist)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        alignItems: 'flex-end'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      tone: "tertiary",
      selected: difficulty === 'easy',
      onClick: () => setMode('easy')
    }, "Easy \xB7 pick one"), /*#__PURE__*/React.createElement(Chip, {
      tone: "tertiary",
      selected: difficulty === 'hard',
      onClick: () => setMode('hard')
    }, "Hard \xB7 type it")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      tone: "secondary",
      selected: !timed,
      onClick: () => setPace(false)
    }, "Untimed"), /*#__PURE__*/React.createElement(Chip, {
      tone: "secondary",
      selected: timed,
      onClick: () => setPace(true)
    }, "Timed \xB7 ", TIME, "s")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center',
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(Chip, null, "Blank ", Math.min(idx + 1, blanks.length), " of ", blanks.length), /*#__PURE__*/React.createElement(Chip, {
      tone: "secondary"
    }, correct, " right"), timed && /*#__PURE__*/React.createElement(Chip, {
      tone: "tertiary",
      selected: started && left <= 10
    }, window.LR.fmt(Math.max(left, 0)), " left")), /*#__PURE__*/React.createElement("div", {
      style: {
        font: '400 clamp(28px, 3.6vw, 44px)/1.45 var(--font-display)',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        gap: 4
      }
    }, song.lines.map((l, li) => /*#__PURE__*/React.createElement("div", {
      key: li,
      style: {
        color: activeLine === -1 || li === activeLine ? 'var(--grey-600)' : 'var(--grey-300)',
        transition: 'color 200ms ease'
      }
    }, l.map((p, pi) => {
      if (typeof p === 'string') return /*#__PURE__*/React.createElement("span", {
        key: pi
      }, p);
      bi++;
      const k = bi;
      const st = k < answers.length ? answers[k].ok ? 'correct' : 'wrong' : k === idx && started ? 'active' : 'empty';
      return /*#__PURE__*/React.createElement(LyricBlank, {
        key: pi,
        answer: p.a,
        value: k < answers.length ? answers[k].v : val,
        state: st,
        mode: difficulty === 'hard' ? 'type' : 'choice',
        onChange: setVal,
        onSubmit: submit
      });
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'center'
      }
    }, !started ? /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      onClick: () => {
        setStarted(true);
        setPlaying(true);
      }
    }, "Press play & start") : difficulty === 'easy' ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
        gap: 12,
        width: '100%',
        maxWidth: 720
      }
    }, choicesFor(blanks[idx].a, idx).map(c => {
      const st = flash ? c === blanks[idx].a ? 'correct' : c === flash.v ? 'wrong' : 'default' : 'default';
      return /*#__PURE__*/React.createElement(Button, {
        key: c,
        variant: "choice",
        size: "lg",
        full: true,
        state: st,
        onClick: () => submit(c)
      }, c);
    })) : /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center',
        flexWrap: 'wrap',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: '400 14px var(--font-sans)',
        color: 'var(--grey-500)'
      }
    }, "Type the missing word and hit Enter. Spelling counts. Capitals don't."), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      onClick: () => submit(val)
    }, "Submit"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      onClick: () => submit('')
    }, "Skip")))), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'sticky',
        bottom: 0
      }
    }, /*#__PURE__*/React.createElement(PlayerBar, {
      title: song.title,
      artist: song.artist,
      tone: song.tone,
      playing: playing,
      position: pos,
      duration: song.dur,
      onToggle: () => {
        if (!started) setStarted(true);
        setPlaying(p => !p);
      }
    })));
  }
  window.Play = Play;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Play.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Profile.jsx
try { (() => {
(function () {
  const {
    Chip,
    StatBlock
  } = window.ColorPaletteDesignSystem_2280bf;
  function Profile({
    history,
    go
  }) {
    const {
      songs
    } = window.LR;
    const avg = Math.round(history.reduce((s, h) => s + h.pct, 0) / history.length);
    const hard = history.filter(h => h.mode === 'Hard' && h.pct >= 75).length;
    return /*#__PURE__*/React.createElement("main", {
      style: {
        padding: '72px var(--lr-pad)',
        display: 'flex',
        flexDirection: 'column',
        gap: 72,
        maxWidth: 1260,
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        gap: 24,
        alignItems: 'center',
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 96,
        height: 96,
        borderRadius: '50%',
        background: 'var(--primary-200)',
        display: 'grid',
        placeItems: 'center',
        font: '500 36px var(--font-display)',
        color: 'var(--primary-700)'
      }
    }, "LN"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        font: '500 48px/1.19 var(--font-sans)',
        letterSpacing: '-1px'
      }
    }, "@lyricnerd"), /*#__PURE__*/React.createElement("span", {
      style: {
        font: '400 20px/31px var(--font-sans)',
        letterSpacing: '-0.4px',
        color: 'var(--grey-500)'
      }
    }, "Listening since March. Mostly honest about it."))), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement(StatBlock, {
      label: "Songs played",
      value: history.length,
      tone: "primary"
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Avg accuracy",
      value: `${avg}%`,
      tone: "secondary"
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Best streak",
      value: "9",
      tone: "tertiary",
      hint: "days in a row"
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Hard-mode clears",
      value: hard,
      tone: "quaternary",
      hint: "75% or better"
    })), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        font: '500 32px/1.19 var(--font-sans)',
        letterSpacing: '-0.6px'
      }
    }, "History"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column'
      }
    }, history.map((h, i) => {
      const s = songs.find(x => x.id === h.songId);
      return /*#__PURE__*/React.createElement("div", {
        key: i,
        role: "button",
        tabIndex: 0,
        onClick: () => go('play', {
          id: s.id
        }),
        style: {
          display: 'grid',
          gridTemplateColumns: '40px minmax(0, 1fr) auto 64px 64px 64px',
          gap: 16,
          alignItems: 'center',
          padding: '12px 0',
          borderTop: i ? '1px solid var(--grey-100)' : 0,
          cursor: 'pointer'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 40,
          height: 40,
          borderRadius: 8,
          background: `var(--${s.tone}-300)`
        }
      }), /*#__PURE__*/React.createElement("div", {
        style: {
          minWidth: 0
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          font: '600 14px/1.4 var(--font-sans)'
        }
      }, s.title), /*#__PURE__*/React.createElement("div", {
        style: {
          font: '400 14px/1.4 var(--font-sans)',
          color: 'var(--grey-500)'
        }
      }, s.artist)), /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 6
        }
      }, /*#__PURE__*/React.createElement(Chip, {
        size: "sm",
        tone: "tertiary"
      }, h.mode), h.timed && /*#__PURE__*/React.createElement(Chip, {
        size: "sm",
        tone: "secondary"
      }, "Timed")), /*#__PURE__*/React.createElement("span", {
        style: {
          font: '400 14px var(--font-mono)',
          textAlign: 'right'
        }
      }, h.pct, "%"), /*#__PURE__*/React.createElement("span", {
        style: {
          font: '400 14px var(--font-mono)',
          textAlign: 'right'
        }
      }, h.score), /*#__PURE__*/React.createElement("span", {
        style: {
          font: '400 14px var(--font-sans)',
          color: 'var(--grey-500)',
          textAlign: 'right'
        }
      }, h.date));
    }))));
  }
  window.Profile = Profile;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Profile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/Results.jsx
try { (() => {
(function () {
  const {
    Button,
    Chip,
    LyricBlank,
    StatBlock
  } = window.ColorPaletteDesignSystem_2280bf;
  const verdict = p => p === 100 ? 'Flawless. Are you in the band?' : p >= 80 ? 'You actually listen. Respect.' : p >= 50 ? 'Decent. The chorus carried you.' : 'Were you even listening?';
  window.scoreOf = r => {
    const c = r.answers.filter(a => a.ok).length;
    return c * (r.difficulty === 'hard' ? 200 : 100) + (r.timed ? Math.max(0, 60 - r.elapsed) * 5 : 0);
  };
  function Results({
    result,
    spin,
    replay
  }) {
    const {
      song,
      answers,
      blanks,
      difficulty,
      timed,
      elapsed
    } = result;
    const correct = answers.filter(a => a.ok).length;
    const pct = Math.round(correct / blanks.length * 100);
    let bi = -1;
    return /*#__PURE__*/React.createElement("main", {
      style: {
        padding: '72px var(--lr-pad)',
        display: 'flex',
        flexDirection: 'column',
        gap: 72,
        maxWidth: 1260,
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24,
        alignItems: 'flex-start'
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      tone: song.tone,
      size: "sm"
    }, song.title, " \u2014 ", song.artist), /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        font: '500 clamp(48px, 6vw, 79px)/1.19 var(--font-sans)',
        letterSpacing: '-1.501px',
        textWrap: 'balance'
      }
    }, verdict(pct)), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        maxWidth: 585,
        font: '400 20px/31px var(--font-sans)',
        letterSpacing: '-0.4px',
        color: 'var(--text-body)'
      }
    }, "You filled ", correct, " of ", blanks.length, " blanks", answers.length < blanks.length ? ' before the clock ran out' : '', "."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: 24,
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement(StatBlock, {
      label: "Score",
      value: window.scoreOf(result),
      tone: "primary",
      hint: difficulty === 'hard' ? '200 per word' : '100 per word'
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Accuracy",
      value: `${pct}%`,
      tone: "secondary",
      hint: `${correct} of ${blanks.length} blanks`
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Time",
      value: window.LR.fmt(elapsed),
      tone: "tertiary",
      hint: timed ? 'Timed · time bonus on' : 'Untimed'
    }), /*#__PURE__*/React.createElement(StatBlock, {
      label: "Mode",
      value: difficulty === 'hard' ? 'Hard' : 'Easy',
      tone: "quaternary",
      hint: difficulty === 'hard' ? 'Typed it' : 'Picked it'
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      onClick: spin
    }, "Spin again"), /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "secondary",
      onClick: () => replay(difficulty)
    }, "Replay"), /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      variant: "ghost",
      onClick: () => replay(difficulty === 'hard' ? 'easy' : 'hard')
    }, difficulty === 'hard' ? 'Go easy on me' : 'Try hard mode'))), /*#__PURE__*/React.createElement("section", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        font: '500 32px/1.19 var(--font-sans)',
        letterSpacing: '-0.6px'
      }
    }, "The receipts"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: '400 28px/1.6 var(--font-display)',
        color: 'var(--grey-600)'
      }
    }, song.lines.map((l, li) => /*#__PURE__*/React.createElement("div", {
      key: li
    }, l.map((p, pi) => {
      if (typeof p === 'string') return /*#__PURE__*/React.createElement("span", {
        key: pi
      }, p);
      bi++;
      const a = answers[bi];
      return /*#__PURE__*/React.createElement(LyricBlank, {
        key: pi,
        answer: p.a,
        value: a ? a.v : '',
        state: !a ? 'revealed' : a.ok ? 'correct' : 'wrong'
      });
    }))))));
  }
  window.Results = Results;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/Results.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lyric-roulette/data.js
try { (() => {
(function () {
  const parse = t => t.split(/(\{[^}]+\})/).filter(Boolean).map(p => p[0] === '{' ? {
    a: p.slice(1, -1)
  } : p);
  const song = (id, title, artist, genre, tone, dur, snippet, text) => ({
    id,
    title,
    artist,
    genre,
    tone,
    dur,
    snippet,
    lines: text.map(parse)
  });
  const songs = [song('s1', 'Neon Tide', 'The Paper Lanterns', 'Indie', 'primary', 204, 'counting ____ like sheep', ['We were dancing on the {rooftop}', 'counting {satellites} like sheep', 'every light across the {city}', 'was a promise we could {keep}', 'so turn the {radio} up louder', 'let the {morning} wait outside']), song('s2', 'Velvet Static', 'Mira Vale', 'Pop', 'tertiary', 187, 'with your voice in ____', ['You call me at {midnight}', 'with your voice in {stereo}', "I pretend that I'm {sleeping}", 'but I never let you {go}']), song('s3', 'Slow Orbit', 'Low Satellites', 'Synth', 'secondary', 241, 'drifting past the ____', ['Hold the {signal} steady', 'we are drifting past the {moon}', 'if the engine {fails} tonight', "I'll be home to you {soon}"]), song('s4', 'Paper Boats', 'June & the Harbor', 'Folk', 'quaternary', 198, 'send it down the ____', ['Fold a {letter} into sails', 'send it down the {river}', 'if it reaches you by {Sunday}', "you'll know I'm still a {believer}"]), song('s5', 'Glasshouse', 'Static Bloom', 'Rock', 'grey', 223, 'watch the ____ break apart', ['Throw a {stone} at the window', 'watch the {sunlight} break apart', 'we built it all from {glass}, love', 'right down to the {heart}']), song('s6', 'Gold Line', 'Mira Vale', 'Soul', 'tertiary', 176, 'where the ____ play all night', ['Take the {last} train downtown', 'where the {trumpets} play all night', "I've got {nothing} in my pockets", 'but my shoes are shining {bright}'])];
  const artists = [{
    name: 'The Paper Lanterns',
    tone: 'primary'
  }, {
    name: 'Mira Vale',
    tone: 'tertiary'
  }, {
    name: 'Low Satellites',
    tone: 'secondary'
  }, {
    name: 'June & the Harbor',
    tone: 'quaternary'
  }, {
    name: 'Static Bloom',
    tone: 'grey'
  }];
  const history = [{
    songId: 's2',
    date: 'Sep 26',
    mode: 'Hard',
    timed: true,
    pct: 75,
    score: 760
  }, {
    songId: 's1',
    date: 'Sep 26',
    mode: 'Easy',
    timed: false,
    pct: 100,
    score: 600
  }, {
    songId: 's4',
    date: 'Sep 24',
    mode: 'Easy',
    timed: true,
    pct: 50,
    score: 355
  }, {
    songId: 's5',
    date: 'Sep 22',
    mode: 'Hard',
    timed: false,
    pct: 75,
    score: 600
  }, {
    songId: 's3',
    date: 'Sep 21',
    mode: 'Easy',
    timed: false,
    pct: 25,
    score: 100
  }];
  const blankCount = s => s.lines.flat().filter(p => typeof p !== 'string').length;
  const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  const allAnswers = [...new Set(songs.flatMap(s => s.lines.flat().filter(p => typeof p !== 'string').map(p => p.a)))];
  window.LR = {
    songs,
    artists,
    history,
    genres: ['Indie', 'Pop', 'Synth', 'Folk', 'Rock', 'Soul'],
    blankCount,
    fmt,
    allAnswers
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lyric-roulette/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.LyricBlank = __ds_scope.LyricBlank;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.PlayerBar = __ds_scope.PlayerBar;

__ds_ns.SongCard = __ds_scope.SongCard;

})();
